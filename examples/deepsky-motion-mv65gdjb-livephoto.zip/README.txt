Apple has no single-file Live Photo format; a Live Photo is a still + a MOV tied by a shared content identifier.

This bundle contains that exact pair plus this manifest.

macOS: unzip and use a converter (e.g. the `make-livephoto` style tools) to import into Photos, or drop both files into an iCloud Photos folder.

The MOV alone plays anywhere; the HEIC alone is a normal still.
